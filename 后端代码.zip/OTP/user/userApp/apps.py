from django.apps import AppConfig


class UserbackappConfig(AppConfig):
    name = 'userBackApp'
