from django.apps import AppConfig


class Sensorback2AppConfig(AppConfig):
    name = 'sensorBack2App'
