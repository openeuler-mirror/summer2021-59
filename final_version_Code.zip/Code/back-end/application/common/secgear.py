import os
import sys
import time
import math

defaultIn = sys.stdin
defaultOut = sys.stdout
path = "application/common/secgear_Enclave"

def initServer():
    '''
    Input [time], generate and return [K_U, K_SN].
    '''
    os.system("{0} initServer {1} > buf.tmp".format(path, math.floor(time.time())))
    sys.stdin = open("buf.tmp", "r")
    Ku, Ksn = input(), input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (Ku.zfill(256), Ksn.zfill(256))

def initNode(IDj, Ksn):
    '''
    Input [ID_j, K_SN, time], generate [r_j, DK_j^old] and return [PTC_j^old, CN_j, PDK_j^old].
    '''
    os.system("{0} initNode {1} {2} {3} > buf.tmp".format(path, IDj, Ksn, math.floor(time.time())))
    sys.stdin = open("buf.tmp", "r")
    PTC, CN, PDK = input(), input(), input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (PTC, CN, PDK)

def register(IDsc, ri, RPWi, Ku):
    '''
    Input [ID_SC, r_i, RPW_i, K_U, time], generate [DK_i^old] and return [B_i, PTC_i^old, PDK_i^old, BN_i^old].
    '''
    os.system("{0} register {1} {2} {3} {4} {5} > buf.tmp".format(path, IDsc, ri, RPWi, Ku, math.floor(time.time())))
    sys.stdin = open("buf.tmp", "r")
    B, PTC, PDK, BN = input(), input(), input(), input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (B, PTC, PDK, BN)

def verify(BNi, PTCi, Ku):
    '''
    Input [BN_i^old, PTC_i^old, K_U] and return [r_i].
    '''
    os.system("{0} verify {1} {2} {3} > buf.tmp".format(path, BNi, PTCi, Ku))
    sys.stdin = open("buf.tmp", "r")
    ri = input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (ri)

def exchange(IDj, CNj, Ksn):
    '''
    Input [ID_j, CN_j, K_SN] and return [r_j].
    '''
    os.system("{0} exchange {1} {2} {3} > buf.tmp".format(path, IDj, CNj, Ksn))
    sys.stdin = open("buf.tmp", "r")
    rj = input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (rj)

def update(PTCi, ri, Ku):
    '''
    Input [PTC_i^new, r_i, K_U] and return [BN_i^new].
    '''
    os.system("{0} update {1} {2} {3} > buf.tmp".format(path, PTCi, ri, Ku))
    sys.stdin = open("buf.tmp", "r")
    BN = input()
    os.system("echo > buf.tmp")
    sys.stdin = defaultIn
    return (BN)

if __name__=='__main__':
    print(initServer()) #313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b, 313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c
    print(initNode(0x12345678,"313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c"))
    print(register(0x1345,0x13463,'313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b','313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b'))
    print(verify('313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c','313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c','313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b'))
    print(exchange(0x23412,'313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b','313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c'))
    print(update('313e1c6c1d283a12cc422c2934ff5804ab51cde47d81643075adadcf6d946c0f351fca2e9e0d948658f5d9a4f9b543ec3b5e92913f16994d5346343e302b328daaa318a241bf4fe65e38a4c628a0a9771edf71d460ba39a75f41471114081afe49a958bdb6f85118e0365d7af0ba6a963d4c903972be4438c021ffa7652a036c',0x1243234,'313e1c6c00c4b8dea441e55889a67cc56415f5c7ccdc0b8d1da386d93cd2144992dc163ea9bc4d9ee9e0d446c61c54b0e35576a3c2843c3e592ac8548f73ef39ab45f48134bf8daf00df4f5d0acf4f41bd2029e2ab213b21895f0002a8a9bf52c5cc64ac324d41cee3c07542bb20aa2876970a789ed4d4134310a18038bad60b'))
