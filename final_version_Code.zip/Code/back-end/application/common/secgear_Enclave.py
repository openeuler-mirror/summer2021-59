import os
import sys

UM1 = 0xffffffff
randSeed = 0

def rightRotate(x,u):
    u&=31
    xx=(x<<32)|x
    return ((xx>>u)&UM1)

def leftRotate(x,u):
    u&=31
    xx=(x<<32)|x
    return ((xx>>(32-u))&UM1)

def sha256(src=''):
    hexLen=len(src)
    src+='8'
    while(len(src)%128!=112):
        src+='0'
    src+=hex(hexLen<<2)[2:].zfill(16)
    k=[0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]
    h=[0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
    tmpnum=[]
    for i in range(0,len(src),8):
        tmpnum.append(int(src[i:i+8],16))
    for i in range(0,len(tmpnum),16):
        w=[]
        for j in range(16):
            w.append(tmpnum[i+j])
        for j in range(16,64):
            s0 = rightRotate(w[j - 15], 7) ^ rightRotate(w[j - 15], 18) ^ (w[j - 15] >> 3)
            s1 = rightRotate(w[j - 2], 17) ^ rightRotate(w[j - 2], 19) ^ (w[j - 2] >> 10)
            w.append((w[j - 16] + s0 + w[j - 7] + s1) & UM1)
        t=[]
        for j in range(8):
            t.append(h[j])
        for j in range(64):
            S1 = rightRotate(t[4], 6) ^ rightRotate(t[4], 11) ^ rightRotate(t[4], 25)
            ch = (t[4] & t[5]) ^ ((t[4] ^ UM1)&t[6])
            tmp1 = (t[7] + S1 + ch + k[j] + w[j]) & UM1
            S0 = rightRotate(t[0], 2) ^ rightRotate(t[0], 13) ^ rightRotate(t[0], 22)
            maj = (t[0] & t[1]) ^ (t[0] & t[2]) ^ (t[1] & t[2])
            tmp2 = (S0 + maj) & UM1
            t[7] = t[6]
            t[6] = t[5]
            t[5] = t[4]
            t[4] = (t[3] + tmp1) & UM1
            t[3] = t[2]
            t[2] = t[1]
            t[1] = t[0]
            t[0] = (tmp1 + tmp2) & UM1
        for j in range(8):
            h[j]=(h[j] + t[j]) & UM1
    result=''
    for i in range(8):
        result+=hex(h[i])[2:].zfill(8)
    return result

def getNextRand(preRand,rounds=1):
    if preRand==0:
        return UM1
    x=preRand
    x&=UM1
    if rounds==1:
        x^=(x<<13)&UM1
        x^=(x>>17)&UM1
        x^=(x<<5)&UM1
        return x
    for i in range(rounds):
        x=getNextRand(x)
    return x

keys = [0, 0]
keybuf = [0, 0]
buffer = ''

def setKeys(src):
    global keys
    keys[0] = int(src[0], 16)
    keys[1] = int(src[1], 16)

def sealKeys():
    global keys
    keys[0]^=int("12345678abcdef", 16)
    keys[1]^=int("12345678abcdef", 16)

def unsealKeys():
    global keybuf, keys
    keybuf[0] = keys[0]
    keybuf[1] = keys[1]
    keybuf[0]^=int("12345678abcdef", 16)
    keybuf[1]^=int("12345678abcdef", 16)

def genKeys(src):
    global randSeed, keys
    randSeed=int(src)
    keys[0], keys[1] = '', ''
    for i in range(32):
        keys[0] += hex(getNextRand(randSeed, i))[2:].zfill(8)
    randSeed = getNextRand(randSeed, 1024)
    for i in range(32):
        keys[1] += hex(getNextRand(randSeed, i))[2:].zfill(8)
    sealKeys()

def getKu():
    global buffer
    buffer = keys[0]

def getKsn():
    global buffer
    buffer = keys[1]

def setRandSeed(src):
    global randSeed
    randSeed = int(src)

IDsc=''
ri=''
rpw=''

def main(argc,argv):
    if argc>1:
        if argv[1]=='initServer':
            genKeys(argv[2])
            getKu()
            print(buffer)
            getKsn()
            print(buffer)
        elif argv[1]=='initNode':
            pass
        elif argv[1]=='register':
            setRandSeed(argv[5])
        elif argv[1]=='verify':
            pass
        elif argv[1]=='exchange':
            pass
        elif argv[1]=='update':
            pass

if __name__=='__main__':
    main(len(sys.argv),sys.argv)