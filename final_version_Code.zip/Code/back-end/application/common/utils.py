import os
import json
import hashlib

from sqlalchemy.sql.expression import false
from application.common.secgear import initServer

CaptchaAppId = "2024376293"

def sha256(x):
    return hashlib.sha256(x.encode('utf-8')).hexdigest()

def init_paramters():
    if os.path.exists("pubkey"):
        with open("pubkey", "r") as f:
            parameter = json.load(f)
    else:
        KU, KSN = initServer()
        parameter = {
            "KU": KU,
            "KSN": KSN,
            "NODES": False
        }
        with open("pubkey", "w") as f:
            json.dump(parameter, f)
    return parameter
    
def update_paramters():
    if os.path.exists("pubkey"):
        with open("pubkey", "r") as f:
            parameter = json.load(f)
            parameter["NODES"] = True
            with open("pubkey", "w") as f:
                json.dump(parameter, f)
    else:
        KU, KSN = initServer()
        parameter = {
            "KU": KU,
            "KSN": KSN,
            "NODES": False
        }
        with open("pubkey", "w") as f:
            json.dump(parameter, f)
    return parameter

if __name__ == "__main__":
    print(init_paramters())
