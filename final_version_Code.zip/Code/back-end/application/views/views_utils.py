import logging
from secgear.application.common.utils import sha256

from sqlalchemy.sql.expression import true
from application.common.token_tools import create_token, login_required, verify_token
import json
from application.common.secgear import initNode, register, verify, exchange, update
from flask import jsonify
import time
from application.views.models.gwn import Gwn
from application.views.models.node import Node
from application.views.models.dac import Dac
from application.views.models.auth import Auth
from sqlalchemy import and_, or_
from application import db
from application.common.utils import init_paramters, update_paramters
from datetime import datetime
# from application.common.sensor import login_check
import os
import math
import random

PARAMETERS = init_paramters()

def init_nodes(N = 8):
    try:
        for i in range(N):
            IDj = str(i+1)
            ptc, cn, pdk = initNode(IDj, PARAMETERS["KSN"])
            pieceG = Gwn(
                id=IDj,
                cn=cn,
                pdk=pdk,
                data_created_time=datetime.now(),
            )
            db.session.add(pieceG)
            pieceN = Node(
                id=IDj,
                ptc=ptc,
                data_created_time=datetime.now(),
            )
            db.session.add(pieceN)
            db.session.commit()
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Init Nodes Error {}".format(str(err)))

def timestamp_verify(request):
    try:
        ts = request["ts"]
        print(time.time() - float(ts))
        return True
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Timestamp Check Error {}".format(str(err)))


def phone_verfiy(phone, code):
    try:
        return True
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Phone Check Error {}".format(str(err)))


def get_login_params(request, id=None):
    request = json.loads(request.get_data())
    if not timestamp_verify(request):
        jsonify(code=4101, msg="请求超时")
    try:
        if not id:
            id = request["id"]
        user = Dac.query.get(id)
        if user:
            token = create_token(id)
            return jsonify(code=0, msg="成功", data={"idsc": user.idsc, "AN": user.an, "Bi": user.b, "ts": time.time()}, token=token)
        else:
            return jsonify(code=4103, msg="用户名错误")
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Password Validation Error {}".format(str(err)))


def add_user(request):
    request = json.loads(request.get_data())
    if not timestamp_verify(request):
        jsonify(code=4101, msg="请求超时")
    try:
        id = request["id"]
        idsc = request["idsc"]
        AN = request["AN"]
        rpw = request["rpw"]
        ri = request["ri"]
        if Dac.query.get(id):
            return jsonify(code=4105, msg="用户名已存在")
        Bi, PTCi, PDKi, BNi = register(int(idsc, 16), int(ri, 16), rpw, PARAMETERS["KU"])
        piece = Dac(
            id=id,
            idsc=idsc,
            an=AN,
            b=Bi,
            ptc=PTCi,
            data_created_time=datetime.now(),
            )
        db.session.add(piece)
        piece = Auth(
            ptc=PTCi,
            pdk=PDKi,
            bn=BNi,
            data_created_time=datetime.now())
        db.session.add(piece)
        db.session.commit()
        token = create_token(id)
        if not PARAMETERS["NODES"]:
            init_nodes()
            update_paramters()
        return jsonify(code=0, msg="成功", data={"ts": time.time()}, token=token)
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Add User Error {}".format(str(err)))


def node_communicate(request):
    request = json.loads(request.get_data())
    if not timestamp_verify(request):
        jsonify(code=4101, msg="请求超时")
    try:
        id = request["id"]
        idj = request["idj"] # 1-16
        ri = request["ri"]
        N = request["N"]
        ts = hex(int(request["ts"][4:]))[2:].zfill(8)
        dac = Dac.query.get(id)
        tc = hex(int(dac.ptc, 16) ^ int(sha256(ri + dac.idsc), 16))[2:].zfill(64)
        q1 = sha256(tc + hex(int(idj))[2:].zfill(16) + N + ri)
        pks = hex(int(N, 16) ^ int(sha256(tc + ri + ts), 16))[2:].zfill(64)
        pid = hex(int(idj) ^ int(sha256(tc + ts + N), 16))[2:].zfill(64)
        auth = Auth.query.get(dac.ptc)
        rii = hex(int(verify(auth.bn, dac.ptc, PARAMETERS["KU"]), 16))[2:].zfill(8)
        dk = hex(int(auth.pdk, 16) ^ int(rii, 16))[2:].zfill(8)
        tc = sha256(dk + rii)
        Ni = hex(int(pks, 16) ^ int(sha256(tc + rii + ts), 16))[2:].zfill(64)
        IDj = hex(int(pid, 16) ^ int(sha256(tc + ts + N), 16))[2:].zfill(64)
        q1x = sha256(tc + hex(int(idj))[2:].zfill(16) + N + ri)
        if q1 == q1x:
            gwn = Gwn.query.get(idj)
            ts2 = hex(math.floor(time.time()))[2:]
            rj = hex(int(exchange(idj, gwn.cn, PARAMETERS["KSN"]), 16))[2:].zfill(8)
            dkj = hex(int(gwn.pdk, 16) ^ int(rj, 16))[2:].zfill(8)
            tcj = sha256(dkj + rj)
            pidj = sha256(dkj + hex(int(idj))[2:].zfill(16))
            q2 = sha256(hex(int(tcj, 16) ^ int(N, 16))[2:] + hex(int(idj))[2:].zfill(16))
            pks = hex(int(N, 16) ^ int(sha256(tcj + hex(int(idj))[2:].zfill(16) + ts2), 16))[2:]

            node = Node.query.get(idj)
            tcjj = hex(int(node.ptc, 16) ^ int(pidj, 16))[2:].zfill(8)
            Nii = hex(int(pks, 16) ^ int(sha256(tcj + hex(int(idj))[2:].zfill(16) + ts2), 16))[2:]
            q2x = sha256(hex(int(tcj, 16) ^ int(N, 16))[2:] + hex(int(idj))[2:].zfill(16))
            if q2 == q2x:
                Kj = hex(random.randint(0,(2**64)-1))[2:]
                q3 = sha256(N + Kj + hex(int(tcj, 16) ^ int(idj))[2:])
                ts3 = hex(math.floor(time.time()))[2:]
                pksj = hex(int(Kj, 16) ^ int(sha256(tcj + N + hex(int(idj))[2:].zfill(16) + ts3), 16))[2:].zfill(8)
                keyij = sha256(N + Kj)

                Kjj = hex(int(pksj, 16) ^ int(sha256(tcj + N + hex(int(idj))[2:].zfill(16) + ts3), 16))[2:].zfill(8)
                q3x = sha256(N + Kj + hex(int(tcj, 16) ^ int(idj))[2:])
                if q3 == q3x:
                    pksk = hex(int(Kj, 16) ^ int(sha256(tcj + hex(int(N, 16) ^ int(idj))[2:]), 16))[2:].zfill(8)
                    
                    return jsonify(code=0, msg="成功", data={"keys": {"id_j": idj, "key_ij": keyij}, "ts": time.time()})
                else: 
                    return jsonify(code=4103, msg="认证失败(q3)")
            else: 
                return jsonify(code=4103, msg="认证失败(q2)")
        else:
            return jsonify(code=4103, msg="认证失败")
    except Exception as err:
        logging.log(level=0, msg=str(err))
        return jsonify(code=3000, msg="后台错误: Communication Error {}".format(str(err)))


# def get_embed_parameters(request, hun):
#     request = json.loads(request.get_data())
#     if not timestamp_verify(request):
#         jsonify(code=4101, msg="请求超时")
#     try:
#         cwid = request["cwid"]
#         npw = User.query.get(hun).npw
#         x, mu, k, nwid = embedding(cwid, npw, PARAMETERS["CD"], PARAMETERS["N"], PARAMETERS["CKU"], PARAMETERS["CKW"])
#         watermark = Watermark(
#             watermark_created_time=datetime.now(),
#             nwid=nwid,
#             hun=hun,
#             watermark_name=request.get("watermark_name", ""),
#             watermark_type=request.get("watermark_type", ""),
#             watermark_size=request.get("watermark_size", ""),
#             watermark_m=request.get("watermark_m", ""),
#             watermark_n=request.get("watermark_n", ""),
#             origin_name=request.get("origin_name", ""),
#             origin_type=request.get("origin_type", ""),
#             origin_size=request.get("origin_size", ""),
#             c_parameter_x=x,
#             c_parameter_mu=mu,
#             c_parameter_k=k,
#         )
#         db.session.add(watermark)
#         db.session.commit()
#         return jsonify(code=0, msg="成功", data={"x": x, "mu": mu, "k": k, "ts": time.time()})
#     except Exception as err:
#         logging.log(level=0, msg=str(err))
#         return jsonify(code=3000, msg="后台错误: Get Parameters Error {}".format(str(err)))


# def add_watermarked_image(request, hun):
#     try:
#         user_path = os.path.join(IMAGE_PATH, hun)
#         if not os.path.exists(user_path):
#             os.mkdir(user_path)
#         cwid = request.form['cwid']
#         npw = User.query.get(hun).npw
#         _, _, _, nwid = embedding(cwid, npw, PARAMETERS["CD"], PARAMETERS["N"], PARAMETERS["CKU"], PARAMETERS["CKW"])
#         watermark = Watermark.query.get(nwid)
#         image_path = os.path.join(user_path, nwid)
#         with open(image_path, "wb") as f:
#             f.write(request.files['result'].read())
#         watermark.watermarked_image_path = image_path
#         db.session.add(watermark)
#         db.session.commit()
#         return jsonify(code=0, msg="成功", data={"ts": time.time()})
#     except Exception as err:
#         print(str(err))
#         return jsonify(code=3000, msg="后台错误: Add Watermarked Image Error {}".format(str(err)))


# def get_extract_parameters(request, hun):
#     request = json.loads(request.get_data())
#     if not timestamp_verify(request):
#         jsonify(code=4101, msg="请求超时")
#     try:
#         cwid = request["cwid"]
#         npw = User.query.get(hun).npw
#         _, _, _, nwid = embedding(cwid, npw, PARAMETERS["CD"], PARAMETERS["N"], PARAMETERS["CKU"], PARAMETERS["CKW"])
#         watermark = Watermark.query.get(nwid)
#         return jsonify(code=0, msg="成功", data={"x": watermark.c_parameter_x,
#                                                "mu": watermark.c_parameter_mu,
#                                                "k": watermark.c_parameter_k,
#                                                "name": watermark.watermark_name,
#                                                "type": watermark.watermark_type,
#                                                "m": watermark.watermark_m,
#                                                "n": watermark.watermark_n,
#                                                "ts": time.time()})
#     except Exception as err:
#         print(str(err))
#         return jsonify(code=3000, msg="后台错误: Get Watermarked Image Error {}".format(str(err)))
