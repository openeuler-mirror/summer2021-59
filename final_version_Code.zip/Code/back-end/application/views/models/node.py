from application import db
from datetime import datetime


class Node(db.Model):
    __tablename__ = "node"
    id = db.Column(db.String(16), primary_key=True, comment="ID")
    ptc = db.Column(db.String(64), comment="PTC")
    data_created_time = db.Column(db.DateTime, default=datetime.now())
