from application import db
from datetime import datetime


class Gwn(db.Model):
    __tablename__ = "gwn"
    id = db.Column(db.String(16), primary_key=True, comment="ID")
    cn = db.Column(db.String(64), comment="CN")
    pdk = db.Column(db.String(256), comment="PDK")
    data_created_time = db.Column(db.DateTime, default=datetime.now())
