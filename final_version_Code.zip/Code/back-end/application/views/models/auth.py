from application import db
from datetime import datetime


class Auth(db.Model):
    __tablename__ = "auth"
    ptc = db.Column(db.String(64), primary_key=True, comment="PTC")
    pdk = db.Column(db.String(32), comment="PDK")
    bn = db.Column(db.String(64), comment="BN")
    data_created_time = db.Column(db.DateTime, default=datetime.now())

if __name__ == "__main__":
    print(datetime.now())
