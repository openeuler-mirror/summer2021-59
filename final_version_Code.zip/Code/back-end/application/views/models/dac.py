from application import db
from datetime import datetime


class Dac(db.Model):
    __tablename__ = "DAC"
    id = db.Column(db.String(16), primary_key=True, comment="ID")
    idsc = db.Column(db.String(16), comment="IDsc")
    an = db.Column(db.String(64), comment="AN")
    b = db.Column(db.String(64), comment="B")
    ptc = db.Column(db.String(64), comment="PTC")
    # phone = db.Column(db.String(16), unique=True, comment="手机")
    data_created_time = db.Column(db.DateTime, default=datetime.now())

if __name__ == "__main__":
    print(datetime.now())
