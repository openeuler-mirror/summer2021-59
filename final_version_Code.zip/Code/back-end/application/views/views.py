from application.common.token_tools import create_token, login_required, verify_token
from application.common.utils import CaptchaAppId, init_paramters
from application.views.views_utils import get_login_params, add_user, node_communicate
from flask import jsonify, request
from application.views.models.gwn import Gwn
from application.views.models.node import Node
from application.views.models.dac import Dac
from application.views.models.auth import Auth
import json
import time
from application import db
import datetime

from . import index_blu

@index_blu.route("/tools/init", methods=["GET"])
def init():
    return jsonify(code=0, msg="成功", data={"AppId": CaptchaAppId})


@index_blu.route('/login', methods=["POST"])
def login():
    return get_login_params(request)


@index_blu.route('/communicate', methods=["POST"])
def communicate():
    return node_communicate(request)


@index_blu.route('/register', methods=["POST"])
def register():
    return add_user(request)


@index_blu.route('/getNodes', methods=["GET"])
@login_required
def getNodes():
    nodes = [{"id": i.id,
            } for i in Node.query.filter(Node.id)]
    return jsonify(code=0, msg="成功", tables={"nodes": nodes, "ts": time.time()})
 

@index_blu.route('/dataTables', methods=["GET"])
@login_required
def getTables():
    gwn = [{"id": i.id,
            "cn": i.cn,
            "pdk": i.pdk,
            "time": i.data_created_time,
            } for i in Gwn.query.filter(Gwn.id)]
    node = [{"id": i.id,
            "ptc": i.ptc,
            "time": i.data_created_time,
            } for i in Node.query.filter(Node.id)]
    dac = [{"id": i.id,
            "idsc": i.idsc,
            "an": i.an,
            "b": i.b,
            "ptc": i.ptc,
            "time": i.data_created_time,
            } for i in Dac.query.filter(Dac.id)]
    auth = [{"ptc": i.ptc,
            "pdk": i.pdk,
            "bn": i.bn,
            "time": i.data_created_time,
            } for i in Auth.query.filter(Auth.ptc)]
    return jsonify(code=0, msg="成功", tables={"gwn": gwn, "node": node, "dac": dac, "auth": auth, "ts": time.time()})


# @index_blu.route('/validate', methods=["POST"])
# @login_required
# def validate():
#     hun = verify_token(request.headers["Authorization"])["id"]
#     return check_password(request, hun)


# @index_blu.route('/embed', methods=["POST"])
# @login_required
# def embed():
#     hun = verify_token(request.headers["Authorization"])["id"]
#     return get_embed_parameters(request, hun)


# @index_blu.route('/add', methods=["POST"])
# @login_required
# def add():
#     hun = verify_token(request.headers["Authorization"])["id"]
#     return add_watermarked_image(request, hun)


# @index_blu.route('/extract', methods=["POST"])
# @login_required
# def extract():
#     hun = verify_token(request.headers["Authorization"])["id"]
#     return get_extract_parameters(request, hun)


# @index_blu.route('/', methods=["GET"])
# @login_required
# def get_username():
#     hun = verify_token(request.headers["Authorization"])
#     return jsonify(code=0, msg="成功", data={"hun": hun, "ts": time.time()})
