<template>
  <div class="main_page">
    <el-form :model="forms" :rules="rules" ref="ruleForm" @submit.prevent>
      <el-form-item prop="idj">
        <el-input
          placeholder="请输入节点编号（1-16）"
          type="text"
          required="required"
          v-model="forms.idj"
          prefix-icon="el-icon-user-solid"
          @keyup.enter="communicate('ruleForm')"
        ></el-input>
      </el-form-item>
      <div class="mp-btn">
        <el-button @click="communicate('ruleForm')" type="primary">确定 </el-button>
      </div>
    </el-form>
  </div>
  <div>
    <el-table :data="keys" style="width: 100%; height: 100%">
      <el-table-column prop="id_j" label="ID_j" width="180">
      </el-table-column>
      <el-table-column prop="key_ij" label="Key_{ij}" width="540">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
let communicate = require("@/assets/js/axios/api").communicate;
let sha256 = require("@/assets/js/encrypt/sha256");
export default {
  name: "MainPage",
  data() {
    return {
      forms: {
        idj: "",
      },
      keys: [],
    };
  },
  methods: {
    communicate(formName) {
      let that = this;
      let id = localStorage.getItem("id");
      let idj = this.forms.idj;
      let ri = localStorage.getItem("ri");
      let N = localStorage.getItem("N");
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let captcha = new window.TencentCaptcha(
            localStorage.getItem("AppID"),
            function (res) {
              if (res.ret === 0) {
                let params = {
                  id: id,
                  idj: idj,
                  ri: ri,
                  N: N,
                  ts: new Date().getTime(),
                };
                console.log("pts: ", params.ts);
                communicate(params).then(function (response) {
                  if (response.code === 0) {
                    that.keys=response.data.keys;
                    } else {
                    that.$message({
                      message: "错了哦! " + response.msg,
                      center: true,
                      type: "error",
                    });
                  }
                });
              }
            }
          );
          captcha.show();
        } else {
          return false;
        }
      });
    },
  },
};
</script>

<style scoped>
.main_page {
  text-align: center;
  width: 70%;
  margin: 10px 15% 30px 15%;
  border-radius: 5px;
}

.mp-btn {
  text-align: center;
}

.mp-btn button {
  width: 100%;
  height: 36px;
  margin-top: 10px;
}
</style>