<template>
  <div>
    <el-table :data="gwn" style="width: 100%; height: 100%">
      <el-table-column prop="id" label="ID_j" width="180">
      </el-table-column>
      <el-table-column prop="cn" label="CN_j" width="540">
      </el-table-column>
      <el-table-column prop="pdk" label="PDK_j" width="540">
      </el-table-column>
      <el-table-column prop="time" label="Created Time" width="240">
      </el-table-column>
    </el-table>
  </div>
  <div>
    <el-table :data="node" style="width: 100%; height: 100%">
      <el-table-column prop="id" label="ID_j" width="180">
      </el-table-column>
      <el-table-column prop="ptc" label="PTC_j" width="1080">
      </el-table-column>
      <el-table-column prop="time" label="Created Time" width="240">
      </el-table-column>
    </el-table>
  </div>
  <div>
    <el-table :data="dac" style="width: 100%; height: 100%">
      <el-table-column prop="id" label="ID_i" width="90">
      </el-table-column>
      <el-table-column prop="idsc" label="ID_{SC}" width="90">
      </el-table-column>
      <el-table-column prop="an" label="AN_i" width="360">
      </el-table-column>
      <el-table-column prop="b" label="B_i" width="360">
      </el-table-column>
      <el-table-column prop="ptc" label="PTC_i" width="360">
      </el-table-column>
      <el-table-column prop="time" label="Created Time" width="240">
      </el-table-column>
    </el-table>
  </div>
  <div>
    <el-table :data="auth" style="width: 100%; height: 100%">
      <el-table-column prop="ptc" label="PTC_i" width="540">
      </el-table-column>
      <el-table-column prop="pdk" label="PDK_i" width="180">
      </el-table-column>
      <el-table-column prop="bn" label="BN_i" width="540">
      </el-table-column>
      <el-table-column prop="time" label="Created Time" width="240">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
let getTables = require("@/assets/js/axios/api.js").getTables;
export default {
  name: "Tables of Data",
  data() {
    return {
      gwn: [],
      nodes: [],
      dac: [],
      auth: [],
    };
  },
  mounted() {
    let that = this;
    getTables().then(function (response) {
      if (response.code === 0) {
        that.gwn = response.tables.gwn;
        that.node = response.tables.node;
        that.dac = response.tables.dac;
        that.auth = response.tables.auth;
      } else {
        this.$message({
          message: "错了哦! " + response.msg,
          center: true,
          type: "error",
        });
      }
    });
  },
};
</script>

<style scoped></style>
