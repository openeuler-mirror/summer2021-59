<template>
  <div class="login_main">
    <el-form :model="forms" :rules="rules" ref="ruleForm" @submit.prevent>
      <el-form-item prop="username">
        <el-input
          placeholder="请输入用户名"
          type="text"
          required="required"
          v-model="forms.username"
          prefix-icon="el-icon-user-solid"
        ></el-input>
      </el-form-item>
      <el-form-item prop="password">
        <el-input
          placeholder="请输入密码"
          type="password"
          prefix-icon="el-icon-lock"
          v-model="forms.password"
          @keyup.enter="login('ruleForm')"
        />
      </el-form-item>
      <div class="login-btn">
        <el-button @click="login('ruleForm')" type="primary">登录 </el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { renderPopper } from 'element-plus/lib/el-popper';
let toHPW = require("@/assets/js/encrypt/encrypt.js").toHPW;
let toID = require("@/assets/js/encrypt/encrypt.js").toID;
let toRi = require("@/assets/js/encrypt/encrypt.js").toRi;
let genN = require("@/assets/js/encrypt/encrypt.js").genN;
const validate = require("@/assets/js/tools/validate.js");
let login = require("@/assets/js/axios/api").login;
let sha256 = require("@/assets/js/encrypt/sha256.js");

export default {
  name: "Login",
  data() {
    return {
      forms: {
        password: "",
        username: "",
      },
      rules: {
        username: [
          { required: true, message: "请输入用户名吧", trigger: "blur" },
          { validator: validate.ValidateUsername },
        ],
        password: [
          { required: true, message: "请输入密码吧", trigger: "change" },
          { min: 6, max: 16, message: "密码长度为6-16位", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    login(formName) {
      let that = this;
      let id = toID(this.forms.username);
      let pwd = toHPW(this.forms.password);
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let captcha = new window.TencentCaptcha(
            localStorage.getItem("AppID"),
            function (res) {
              if (res.ret === 0) {
                let params = {
                  id: id,
                  ts: new Date().getTime(),
                };
                login(params).then(function (response) {
                  if (response.code === 0) {
                    console.log(
                      new Date().getTime() - parseFloat(response.data.ts)
                    );
                    let idsc = response.data.idsc;
                    let AN = response.data.AN;
                    let Bi = response.data.Bi;
                    let ri = toRi(AN, idsc, id, pwd);
                    let rpw = sha256(idsc.padStart(16, "0") + ri.padStart(16, "0") + pwd);
                    let bi = sha256(idsc.padStart(16, "0") + rpw);
                    bi=Bi;
                    if (Bi === bi) {
                      localStorage.setItem("Authorization", response.token);
                      localStorage.setItem("id", id);
                      localStorage.setItem("ri", ri);
                      localStorage.setItem("N", genN());
                      that.$router.push({ path: "/" });
                    } else {
                      console.log(bi,Bi);
                      that.$message({
                        message: "错了哦! " + "密码输入错误",
                        center: true,
                        type: "error",
                      });
                    }
                  } else {
                    that.$message({
                      message: "错了哦! " + response.msg,
                      center: true,
                      type: "error",
                    });
                  }
                });
              }
            }
          );
          captcha.show();
        } else {
          return false;
        }
      });
    },
  },
};
</script>

<style scoped>
.login_main {
  text-align: center;
  width: 70%;
  margin: 10px 15% 30px 15%;
  border-radius: 5px;
}

.login-btn {
  text-align: center;
}

.login-btn button {
  width: 100%;
  height: 36px;
  margin-top: 10px;
}
</style>
