let Base64 = require("js-base64").Base64;
let bigInt = require("big-integer");
let sha256 = require("./sha256");

// export function paramsDecrypt(x, hpw, hwid) {
//   let bigInt = require("big-integer");
//   let sha256 = require("@/assets/js/encrypt/sha256");
//   let y = sha256(hpw + hwid, true);
//   return bigInt(x, 16).xor(bigInt(y, 16)).toString(16);
// }

export function toHPW(passwd) {
  return sha256(passwd);
}

export function toID(id) {
  return bigInt(id,36).toString(16);
}

export function toHex(src) {
  return bigInt(id,10).toString(16);
}

export function toIDsc(id) {
  return bigInt(id,16).xor(bigInt("6201eacf",16)).toString(16);
}

export function genRI() {
  return bigInt.randBetween(0, bigInt(2).pow(32).minus(1)).toString(16);
}

export function toAN(idsc, id, pw, ri){
  return (bigInt(sha256(idsc.padStart(16, "0") + id.padStart(16, "0") + pw), 16).xor(bigInt(ri, 16))).toString(16);
}

export function toRPW(idsc, ri, pw){
  return sha256(idsc.padStart(16, "0") + ri.padStart(16, "0") + pw);
}

export function toRi(AN, idsc, id, pw){
  return (bigInt(sha256(idsc.padStart(16, "0") + id.padStart(16, "0") + pw), 16).xor(bigInt(AN, 16))).toString(16);
}

export function genN() {
  return bigInt.randBetween(0, bigInt(2).pow(64).minus(1)).toString(16).padStart(16,"0");
}

// export function toBi(hun, passwd) {
//   let hpw = sha256(passwd);
//   return sha256(hun + hpw);
// }

// export function passwordEncrypt(s_sha256) {
//   let pw = localStorage.getItem("PubKey");
//   let text = bigInt(s_sha256, 16);
//   let pw0, pw1, pwlist, n, e, cpw;
//   pw0 = Base64.decode(pw);
//   pw1 = decodeURIComponent(pw0);
//   pwlist = pw1.split("&");
//   n = bigInt(pwlist[0].slice(2), 16); // mod
//   e = bigInt(pwlist[1].slice(2), 16); // exponent
//   console.log("hpw:" + s_sha256);
//   console.log("hpw_10: ", text);
//   console.log("n:", n);
//   console.log("e: ", e);
//   cpw = text.modPow(e, n);
//   console.log("cpw:" + cpw.toString(16));
//   return cpw.toString(16);
// }
