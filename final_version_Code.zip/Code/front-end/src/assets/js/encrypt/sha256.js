function leftPad(input, num) {
  if (input.length >= num) return input;

  return new Array(num - input.length + 1).join("0") + input;
}

function binary2hex(binary) {
  const binaryLength = 8;
  let hex = "";
  for (let i = 0; i < binary.length / binaryLength; i++) {
    hex += leftPad(
      parseInt(binary.substr(i * binaryLength, binaryLength), 2).toString(16),
      2
    );
  }
  return hex;
}

function hex2binary(hex) {
  const hexLength = 2;
  let binary = "";
  for (let i = 0; i < hex.length / hexLength; i++) {
    binary += leftPad(
      parseInt(hex.substr(i * hexLength, hexLength), 16).toString(2),
      8
    );
  }
  return binary;
}

function str2binary(str) {
  let binary = "";
  for (const ch of str) {
    binary += leftPad(ch.codePointAt(0).toString(2), 8);
  }
  return binary;
}

function rightRotate(str, n) {
  n %= str.length;
  return str.substring(str.length - n) + str.substr(0, str.length - n);
}

function rightShift(str, n) {
  if (n >= str.length) n=str.length;
  return new Array(n + 1).join("0") + str.substr(0,str.length - n);
}

function binaryCal(x, y, method) {
  const a = x || "";
  const b = y || "";
  const result = [];
  let prevResult;

  for (let i = a.length - 1; i >= 0; i--) {
    prevResult = method(a[i], b[i], prevResult);
    result[i] = prevResult[0];
  }
  return result.join("");
}

function xor(x, y) {
  return binaryCal(x, y, (a, b) => [a === b ? "0" : "1"]);
}

function and(x, y) {
  return binaryCal(x, y, (a, b) => [a === "1" && b === "1" ? "1" : "0"]);
}

function or(x, y) {
  return binaryCal(x, y, (a, b) => [a === "1" || b === "1" ? "1" : "0"]); // a === '0' && b === '0' ? '0' : '1'
}

function add(x, y) {
  const result = binaryCal(x, y, (a, b, prevResult) => {
    const carry = prevResult ? prevResult[1] : "0" || "0";

    if (a !== b) return [carry === "0" ? "1" : "0", carry];

    return [carry, a];
  });

  return result;
}

function not(x) {
  return binaryCal(x, undefined, (a) => [a === "1" ? "0" : "1"]);
}

function calMulti(method) {
  return (...arr) => arr.reduce((prev, curr) => method(prev, curr));
}

function k(j) {
  return hex2binary([
    "428a2f98", "71374491", "b5c0fbcf", "e9b5dba5", "3956c25b", "59f111f1", "923f82a4", "ab1c5ed5", "d807aa98", "12835b01", "243185be", "550c7dc3", "72be5d74", "80deb1fe", "9bdc06a7", "c19bf174", "e49b69c1", "efbe4786", "0fc19dc6", "240ca1cc", "2de92c6f", "4a7484aa", "5cb0a9dc", "76f988da", "983e5152", "a831c66d", "b00327c8", "bf597fc7", "c6e00bf3", "d5a79147", "06ca6351", "14292967", "27b70a85", "2e1b2138", "4d2c6dfc", "53380d13", "650a7354", "766a0abb", "81c2c92e", "92722c85", "a2bfe8a1", "a81a664b", "c24b8b70", "c76c51a3", "d192e819", "d6990624", "f40e3585", "106aa070", "19a4c116", "1e376c08", "2748774c", "34b0bcb5", "391c0cb3", "4ed8aa4a", "5b9cca4f", "682e6ff3", "748f82ee", "78a5636f", "84c87814", "8cc70208", "90befffa", "a4506ceb", "bef9a3f7", "c67178f2"][j]);
}

function CF(h, Bi) {
  const wordLength = 32;
  const w = [];

  for (let i = 0; i < 16; i++) {
    w.push(Bi.substr(i * wordLength, wordLength));
  }

  for (let j = 16; j < 64; j++) {
    let s0 = calMulti(xor)(rightRotate(w[j - 15], 7), rightRotate(w[j - 15], 18), rightShift(w[j - 15], 3)),
    s1 = calMulti(xor)(rightRotate(w[j - 2], 17), rightRotate(w[j - 2], 19), rightShift(w[j - 2], 10));
    w.push(calMulti(add)(w[j-16], s0, w[j-7], s1));
  }

  const t = []; 
  for (let j = 0; j < 8; j++) {
    t.push(h.substr(j * wordLength, wordLength));
  }

  let S0, S1, ch, maj, tmp1, tmp2;
  for (let j = 0; j < 64; j++) {
    S1 = calMulti(xor)(rightRotate(t[4], 6), rightRotate(t[4], 11), rightRotate(t[4], 25));
    ch = xor(and(t[4], t[5]), and(not(t[4]), t[6]));
    tmp1 = calMulti(add)(t[7], S1, ch, k(j), w[j]);
    S0 = calMulti(xor)(rightRotate(t[0], 2), rightRotate(t[0], 13), rightRotate(t[0], 22));
    maj = calMulti(xor)(and(t[0], t[1]), and(t[0], t[2]), and(t[1], t[2]));
    tmp2 = add(S0, maj);
    t[7] = t[6];
    t[6] = t[5];
    t[5] = t[4];
    t[4] = add(t[3], tmp1);
    t[3] = t[2];
    t[2] = t[1];
    t[1] = t[0];
    t[0] = add(tmp1, tmp2);
  }

  for (let j = 0; j < 8; j++) {
    t[j] = add(t[j], h.substr(j * 32, 32));
  }

  return [t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7]].join("");
}

module.exports = function sha256(str, ishex = false) {
  let input;
  if (ishex) {
    input = hex2binary(str);
  } else {
    input = str2binary(str);
  }
  const binary = input;

  // 填充
  const len = binary.length;

  // k是满足len + 1 + k = 448mod512的最小的非负整数
  let k = len % 512;

  // 如果 448 <= (512 % len) < 512，需要多补充 (len % 448) 比特'0'以满足总比特长度为512的倍数
  k = k >= 448 ? 512 - (k % 448) - 1 : 448 - k - 1;

  const m = `${binary}1${leftPad("", k)}${leftPad(
    len.toString(2),
    64
  )}`.toString(); // k个0

  const n = (len + k + 65) / 512;

  let h = hex2binary("6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19");
  for (let i = 0; i <= n - 1; i++) {
    const B = m.substr(512 * i, 512);
    h = CF(h, B);
  }
  return binary2hex(h);
};
