import { ElLoading } from "element-plus";

let loadingCount = 0;
let loading;

function sleep(ms, callback) {
  setTimeout(callback, ms)
}
sleep(1000, () => {
  console.log(1000)
})

const startLoading = () => {
  loading = ElLoading.service({
    lock: true,
    text: "加载中...", //可以自定义文字
    background: "rgba(255, 255, 255, 0.7)", //遮罩层背景色
  });
};

const endLoading = () => {
  loading = ElLoading.service({
    // lock: true,
    text: "完成", //可以自定义文字
    // background: "rgba(255, 255, 255, 0.7)", //遮罩层背景色
  });
  sleep(3000);
  loading.close();
};

export const showLoading = () => {
  if (loadingCount === 0) {
    startLoading();
  }
  loadingCount += 1;
};

export const hideLoading = () => {
  if (loadingCount <= 0) {
    return;
  }
  loadingCount -= 1;
  if (loadingCount === 0) {
    endLoading();
  }
};
