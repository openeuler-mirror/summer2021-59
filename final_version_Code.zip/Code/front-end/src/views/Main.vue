<template>
  <div class="main_page">
    <el-container direction="vertical">
      <el-header>
        <el-menu
          background-color="rgb(0,0,0,0.6)"
          :default-active="activeIndex"
          mode="horizontal"
          active-text-color="#ffd04b"
          text-color="white"
          @select="handleSelect"
        >
          <el-menu-item index="1">主页</el-menu-item>
          <el-menu-item index="2">数据展示</el-menu-item>
          <div class="logout-container">
            <el-popconfirm
              class="confirmLogout"
              title="确定要离开吗？"
              confirmButtonText="不要"
              cancelButtonText="好的"
              icon="el-icon-info"
              iconColor="red"
              @cancel="logout"
            >
              <template #reference>
                <el-button
                  size="small"
                  type="warning"
                  icon="el-icon-caret-right"
                  >登出</el-button
                >
              </template>
            </el-popconfirm>
          </div>
        </el-menu>
      </el-header>
      <el-main>
        <el-row type="flex" class="main_component" justify="center">
          <el-card>
            <MainPage v-if="activeIndex === '1'" />
            <DataDisplay v-if="activeIndex === '2'" />
          </el-card>
          <div class="footer">
            Copyright © 2021 基于secGear机密计算框架实现用户信息表保护与“一次一密”. V1.0 <br />
          </div>
        </el-row>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import MainPage from "../components/MainComponents/MainPage";
import DataDisplay from "../components/MainComponents/DataDisplay";

export default {
  name: "Main",
  data() {
    return {
      height: window.innerHeight - 136 + "px",
      activeIndex: "2",
    };
  },
  components: {
    MainPage,
    DataDisplay: DataDisplay,
  },
  methods: {
    handleSelect(key) {
      this.activeIndex = key;
    },
    logout() {
      this.$router.push("/login");
      localStorage.removeItem("Authorization");
      localStorage.removeItem("id");
      localStorage.removeItem("N");
    },
  },
};
</script>

<style scoped>
.main_page {
  width: 100%;
  min-width: 600px;
  height: 100%;
  padding: 0;
}
.main_page .el-header {
  padding: 0;
  min-width: 600px;
  background-image: url("../../resource/bgb.jpeg");
}
.main_page .el-main {
  display: flex;
  padding: 0;
  text-align: center;
  height: 100%;
  width: 100%;
  min-width: 600px;
  background-color: white;
  z-index: 99;
  margin-bottom: 70px;
}
.main_page .footer {
  color: white;
  text-align: center;
  /*margin-top: 240px;*/
  position: fixed;
  bottom: 0;
  padding: 10px 0 5px 0;
  width: 100%;
  height: 60px;
  font-family: serif;
  font-weight: bolder;
  line-height: 1.4;
  background-image: url("../../resource/bgb.jpeg");
}

.main_component {
  width: 100%;
  min-width: 600px;
  display: flex;
  text-align: center;
}
.el-container {
  width: 100%;
  height: 100%;
}
.logout-container {
  background-color: rgba(0, 0, 0, 0);
  text-align: right;
  padding: 0;
}
.el-menu-item.is-disabled {
  opacity: 1;
  cursor: default;
}
.el-menu-item.is-disabled .el-image {
  text-align: center;
  width: 150px;
  margin-top: 10px;
}

.el-button--warning:hover {
  background-color: rgba(255, 255, 255, 0.2);
  padding: 10px 15px 10px 10px;
}
.el-button--warning {
  background-color: rgba(255, 255, 255, 0.1);
  border: black;
  font-weight: bolder;
  padding: 10px 10px 10px 5px;
  font-size: 16px;
  color: white;
  height: 61px;
  margin-top: 0;
}
</style>
